<div class="header links fonts">
    <a href="/" class="logo">DUNNO</a>
    <form action="" method="get">
        <input name="s" placeholder="Искать здесь..." type="search" autocomplete="off">
        <button type="submit"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" class="_4-d9"><path fill="currentColor" d="M11 5a6 6 0 1 0 0 12 6 6 0 0 0 0-12Zm-8 6a8 8 0 1 1 14.281 4.955l4.419 4.33a1 1 0 1 1-1.4 1.43l-4.444-4.357A8 8 0 0 1 3 11Z"></path></svg></button>
    </form>
    <nav>
        <ul>
            <li><a href="/about">О нас</a></li>
            <li><a href="/basket">Корзина<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" class="b2b"><path fill="currentColor" d="M6 6a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2h4a1 1 0 0 1 .986 1.164l-1.582 9.494A4 4 0 0 1 17.46 22H6.54a4 4 0 0 1-3.945-3.342L1.014 9.164A1 1 0 0 1 2 8h4V6Zm2 2h5a1 1 0 1 1 0 2H3.18l1.389 8.329A2 2 0 0 0 6.54 20h10.92a2 2 0 0 0 1.972-1.671L20.82 10H17a1 1 0 0 1-1-1V6a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2Z"></path></svg></a></li>
        </ul>
    </nav>
</div>
