<?php
$db_host="127.0.0.1";
$db_name="DUNNO";
$db_username="root";
$db_pass="";

$db=new PDO("mysql:host=$db_host;dbname=$db_name;",$db_username,$db_pass);
 ?>
